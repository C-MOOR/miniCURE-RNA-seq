# (PART\*) Genomic Data Science {-}

# Introduction to RNA-seq
