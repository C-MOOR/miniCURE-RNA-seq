# C-MOOR Scholars

Meet the C-MOOR Scholars and learn how you can support them

- https://www.cloviscollege.edu/alumni-and-community/c-moor/c-moor-scholars.html
